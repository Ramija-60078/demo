/** The AI lead score shown as a heat strip: cold (slate) → warm (teal) → hot (amber). */
export default function ScoreBar({ score = 0, label = 'Cold', size = 'sm' }) {
  return (
    <div className={`score score-${size} score-${label.toLowerCase()}`} title={`AI score ${score} – ${label}`}>
      <div className="score-track">
        <div className="score-fill" style={{ width: `${score}%` }} />
      </div>
      <span className="score-num">{score}</span>
    </div>
  );
}
