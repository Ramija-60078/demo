import { useState } from 'react';
import { BUDGETS, SOURCES, STATUSES } from '../api';

const empty = { name: '', company: '', jobTitle: '', email: '', phone: '', source: 'Website', status: 'New', budget: 'Unknown', value: '' };

export default function LeadForm({ initial, onSubmit, submitLabel = 'Add lead', busy }) {
  const [f, setF] = useState(() => Object.fromEntries(Object.keys(empty).map((k) => [k, initial?.[k] ?? empty[k]])));
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  return (
    <form
      className="form-grid"
      onSubmit={(e) => {
        e.preventDefault();
        onSubmit({ ...f, value: Number(f.value) || 0 });
      }}
    >
      <label>Full name<input required value={f.name} onChange={set('name')} placeholder="Rohit Sharma" /></label>
      <label>Company<input value={f.company} onChange={set('company')} placeholder="Sharma Textiles" /></label>
      <label>Job title<input value={f.jobTitle} onChange={set('jobTitle')} placeholder="Owner" /></label>
      <label>Deal value (₹)<input type="number" min="0" value={f.value} onChange={set('value')} placeholder="250000" /></label>
      <label>Email<input type="email" value={f.email} onChange={set('email')} placeholder="rohit@company.in" /></label>
      <label>Phone<input value={f.phone} onChange={set('phone')} placeholder="+91 98xxxxxxx" /></label>
      <label>Source<select value={f.source} onChange={set('source')}>{SOURCES.map((s) => <option key={s}>{s}</option>)}</select></label>
      <label>Stage<select value={f.status} onChange={set('status')}>{STATUSES.map((s) => <option key={s}>{s}</option>)}</select></label>
      <label>Budget<select value={f.budget} onChange={set('budget')}>{BUDGETS.map((s) => <option key={s}>{s}</option>)}</select></label>
      <div className="form-actions">
        <button className="btn btn-primary" disabled={busy}>{busy ? 'Saving…' : submitLabel}</button>
      </div>
    </form>
  );
}
