import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api, { errMsg, fmtDate } from '../api';

const blank = { title: '', type: 'Call', dueDate: '', priority: 'Medium', lead: '' };

export default function Tasks() {
  const [tasks, setTasks] = useState(null);
  const [leads, setLeads] = useState([]);
  const [f, setF] = useState(blank);
  const [view, setView] = useState('open');
  const [error, setError] = useState('');

  const load = () => api.get('/tasks').then((r) => setTasks(r.data)).catch((e) => setError(errMsg(e)));
  useEffect(() => {
    load();
    api.get('/leads', { params: { sort: 'name' } }).then((r) => setLeads(r.data));
  }, []);

  const add = async (e) => {
    e.preventDefault();
    try {
      await api.post('/tasks', f);
      setF(blank);
      load();
    } catch (err) { setError(errMsg(err)); }
  };
  const toggle = async (t) => { await api.put(`/tasks/${t._id}`, { done: !t.done }); load(); };
  const remove = async (t) => { await api.delete(`/tasks/${t._id}`); load(); };

  const now = new Date();
  now.setHours(0, 0, 0, 0);
  const shown = (tasks || []).filter((t) => (view === 'open' ? !t.done : view === 'done' ? t.done : true));
  const groups = [
    ['Overdue', shown.filter((t) => !t.done && new Date(t.dueDate) < now)],
    ['Today', shown.filter((t) => !t.done && new Date(t.dueDate).toDateString() === now.toDateString())],
    ['Later', shown.filter((t) => !t.done && new Date(t.dueDate) > now && new Date(t.dueDate).toDateString() !== now.toDateString())],
    ['Completed', shown.filter((t) => t.done)],
  ].filter(([, list]) => list.length);

  return (
    <div className="page">
      <div className="page-head">
        <div><h1>Tasks</h1><p className="muted">Calls, emails and meetings to keep deals moving.</p></div>
        <div className="seg" role="tablist">
          {['open', 'done', 'all'].map((v) => (
            <button key={v} role="tab" aria-selected={view === v} className={view === v ? 'on' : ''} onClick={() => setView(v)}>
              {v === 'open' ? 'To do' : v === 'done' ? 'Completed' : 'All'}
            </button>
          ))}
        </div>
      </div>

      <form className="panel task-form" onSubmit={add}>
        <input required placeholder="What needs doing?" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} aria-label="Task" />
        <select value={f.type} onChange={(e) => setF({ ...f, type: e.target.value })} aria-label="Type">{['Call', 'Email', 'Meeting', 'Follow-up', 'Other'].map((x) => <option key={x}>{x}</option>)}</select>
        <select value={f.lead} onChange={(e) => setF({ ...f, lead: e.target.value })} aria-label="Lead"><option value="">No lead</option>{leads.map((l) => <option key={l._id} value={l._id}>{l.name}</option>)}</select>
        <select value={f.priority} onChange={(e) => setF({ ...f, priority: e.target.value })} aria-label="Priority">{['Low', 'Medium', 'High'].map((x) => <option key={x}>{x}</option>)}</select>
        <input required type="date" value={f.dueDate} onChange={(e) => setF({ ...f, dueDate: e.target.value })} aria-label="Due date" />
        <button className="btn btn-primary">Add task</button>
      </form>

      {error && <p className="error">{error}</p>}
      {!tasks ? <div className="loading">Loading tasks…</div> : groups.length === 0 ? <div className="empty"><p>No tasks here. Add one above.</p></div> : groups.map(([name, list]) => (
        <section key={name} className="task-group">
          <h2 className={name === 'Overdue' ? 'overdue' : ''}>{name} <span className="muted">{list.length}</span></h2>
          <ul className="task-list">
            {list.map((t) => (
              <li key={t._id} className={`task prio-${t.priority.toLowerCase()} ${t.done ? 'done' : ''}`}>
                <input type="checkbox" checked={t.done} onChange={() => toggle(t)} aria-label={`Mark ${t.title} ${t.done ? 'not done' : 'done'}`} />
                <div className="task-body">
                  <strong>{t.title}</strong>
                  <span className="muted small">
                    {t.type}{t.lead ? <> for <Link to={`/leads/${t.lead._id}`}>{t.lead.name}</Link></> : ''}, {t.priority.toLowerCase()} priority
                  </span>
                </div>
                <time>{fmtDate(t.dueDate)}</time>
                <button className="icon-btn" aria-label={`Delete ${t.title}`} onClick={() => remove(t)}>×</button>
              </li>
            ))}
          </ul>
        </section>
      ))}
    </div>
  );
}
