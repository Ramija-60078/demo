import { useEffect, useRef, useState } from 'react';
import api, { errMsg } from '../api';

const starters = ['Who should I call today?', 'What is my revenue forecast?', 'Which leads are going cold?', 'Show my overdue tasks', 'Which lead source works best?', 'What is my win rate?'];

export default function Assistant() {
  const [messages, setMessages] = useState([
    { role: 'ai', text: 'Ask me anything about your leads, pipeline or tasks. I read your live CRM data to answer.' },
  ]);
  const [q, setQ] = useState('');
  const [busy, setBusy] = useState(false);
  const [provider, setProvider] = useState('');
  const end = useRef(null);

  useEffect(() => { api.get('/ai/status').then((r) => setProvider(r.data.provider)); }, []);
  useEffect(() => { end.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  const ask = async (text) => {
    const question = (text ?? q).trim();
    if (!question || busy) return;
    setQ('');
    setMessages((m) => [...m, { role: 'me', text: question }]);
    setBusy(true);
    try {
      const { data } = await api.post('/ai/chat', { question });
      setMessages((m) => [...m, { role: 'ai', text: data.answer }]);
    } catch (e) {
      setMessages((m) => [...m, { role: 'ai', text: errMsg(e), error: true }]);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="page chat-page">
      <div className="page-head">
        <div>
          <h1>AI assistant</h1>
          <p className="muted">{provider === 'offline' ? 'Running on the built-in engine. Add a Gemini or OpenAI key in backend/.env for free-form answers.' : provider ? `Powered by ${provider}.` : ''}</p>
        </div>
      </div>
      <div className="chat">
        <div className="chat-log" aria-live="polite">
          {messages.map((m, i) => (
            <div key={i} className={`bubble ${m.role} ${m.error ? 'err' : ''}`}>{m.text}</div>
          ))}
          {busy && <div className="bubble ai typing">Thinking…</div>}
          <div ref={end} />
        </div>
        <div className="starters">
          {starters.map((s) => <button key={s} className="chip" onClick={() => ask(s)} disabled={busy}>{s}</button>)}
        </div>
        <form className="chat-input" onSubmit={(e) => { e.preventDefault(); ask(); }}>
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Ask about your pipeline" aria-label="Question" />
          <button className="btn btn-primary" disabled={busy || !q.trim()}>Ask</button>
        </form>
      </div>
    </div>
  );
}
