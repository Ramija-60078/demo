import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import api, { STATUSES, errMsg, fmtDate, inr, timeAgo } from '../api';
import ScoreBar from '../components/ScoreBar';
import Modal from '../components/Modal';
import LeadForm from '../components/LeadForm';

export default function LeadDetail() {
  const { id } = useParams();
  const nav = useNavigate();
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  const [note, setNote] = useState('');
  const [editing, setEditing] = useState(false);
  const [busy, setBusy] = useState('');
  const [email, setEmail] = useState({ purpose: 'follow-up', tone: 'friendly', draft: null });
  const [task, setTask] = useState({ title: '', dueDate: '', type: 'Call', priority: 'Medium' });
  const [copied, setCopied] = useState(false);

  const load = () => api.get(`/leads/${id}`).then((r) => setData(r.data)).catch((e) => setError(errMsg(e)));
  useEffect(() => { load(); }, [id]);

  const run = async (key, fn) => {
    setBusy(key);
    setError('');
    try { await fn(); } catch (e) { setError(errMsg(e)); } finally { setBusy(''); }
  };

  if (error && !data) return <p className="error">{error}</p>;
  if (!data) return <div className="loading">Loading lead…</div>;
  const { lead, tasks, activity } = data;
  const setLead = (l) => setData({ ...data, lead: l });

  const changeStatus = (status) => run('status', async () => setLead((await api.patch(`/leads/${id}/status`, { status })).data));
  const rescore = () => run('score', async () => { setLead((await api.post(`/ai/score/${id}`)).data); load(); });
  const addNote = (e) => {
    e.preventDefault();
    run('note', async () => { setLead((await api.post(`/leads/${id}/notes`, { text: note })).data); setNote(''); load(); });
  };
  const save = (body) => run('save', async () => { setLead((await api.put(`/leads/${id}`, body)).data); setEditing(false); });
  const remove = () => {
    if (!confirm(`Delete ${lead.name} and their tasks? This cannot be undone.`)) return;
    run('delete', async () => { await api.delete(`/leads/${id}`); nav('/leads'); });
  };
  const draft = () => run('email', async () => {
    const { data: d } = await api.post('/ai/email', { leadId: id, purpose: email.purpose, tone: email.tone });
    setEmail({ ...email, draft: d });
  });
  const addTask = (e) => {
    e.preventDefault();
    run('task', async () => { await api.post('/tasks', { ...task, lead: id }); setTask({ ...task, title: '', dueDate: '' }); load(); });
  };
  const toggleTask = (t) => run('task', async () => { await api.put(`/tasks/${t._id}`, { done: !t.done }); load(); });

  return (
    <div className="page">
      <Link to="/leads" className="back">← Leads</Link>
      <div className="page-head">
        <div>
          <h1>{lead.name}</h1>
          <p className="muted">{[lead.jobTitle, lead.company].filter(Boolean).join(' at ')}</p>
        </div>
        <div className="head-actions">
          <button className="btn" onClick={() => setEditing(true)}>Edit</button>
          <button className="btn btn-danger" onClick={remove}>Delete</button>
        </div>
      </div>

      <div className="stages" role="group" aria-label="Stage">
        {STATUSES.map((s) => (
          <button key={s} className={`stage ${lead.status === s ? 'on' : ''} stage-${s.toLowerCase()}`} onClick={() => changeStatus(s)} disabled={busy === 'status'}>
            {s}
          </button>
        ))}
      </div>
      {error && <p className="error">{error}</p>}

      <div className="detail">
        <div className="detail-main">
          <section className={`panel ai-panel ai-${lead.ai?.label?.toLowerCase()}`}>
            <div className="panel-head">
              <h2>AI lead score</h2>
              <button className="btn btn-ghost" onClick={rescore} disabled={busy === 'score'}>{busy === 'score' ? 'Scoring…' : 'Score again'}</button>
            </div>
            <div className="ai-score-row">
              <div className="big-score"><strong>{lead.ai?.score}</strong><span>{lead.ai?.label}</span></div>
              <ScoreBar score={lead.ai?.score} label={lead.ai?.label} size="lg" />
            </div>
            <p className="next-action"><b>Next step:</b> {lead.ai?.nextAction}</p>
            <ul className="reasons">{lead.ai?.reasons?.map((r, i) => <li key={i}>{r}</li>)}</ul>
            <p className="muted small">Scored {lead.ai?.scoredAt ? timeAgo(lead.ai.scoredAt) : 'never'} by {lead.ai?.provider === 'offline' ? 'the built-in engine' : lead.ai?.provider}</p>
          </section>

          <section className="panel">
            <h2>Notes</h2>
            <form onSubmit={addNote} className="note-form">
              <textarea rows="3" value={note} onChange={(e) => setNote(e.target.value)} placeholder="What happened on the call? The AI tags the mood and updates the score." />
              <button className="btn btn-primary" disabled={!note.trim() || busy === 'note'}>{busy === 'note' ? 'Saving…' : 'Add note'}</button>
            </form>
            <ul className="notes">
              {[...lead.notes].reverse().map((n) => (
                <li key={n._id}>
                  <span className={`mood mood-${n.sentiment}`}>{n.sentiment}</span>
                  <p>{n.text}</p>
                  <time>{timeAgo(n.createdAt)}</time>
                </li>
              ))}
              {lead.notes.length === 0 && <li className="muted">No notes yet.</li>}
            </ul>
          </section>

          <section className="panel">
            <h2>Write an email with AI</h2>
            <div className="email-controls">
              <select value={email.purpose} onChange={(e) => setEmail({ ...email, purpose: e.target.value })} aria-label="Purpose">
                <option value="follow-up">Follow-up</option>
                <option value="introduction">Introduction</option>
                <option value="meeting-request">Meeting request</option>
                <option value="proposal">Proposal</option>
                <option value="thank-you">Thank you</option>
              </select>
              <select value={email.tone} onChange={(e) => setEmail({ ...email, tone: e.target.value })} aria-label="Tone">
                <option value="friendly">Friendly</option>
                <option value="formal">Formal</option>
                <option value="persuasive">Persuasive</option>
              </select>
              <button className="btn btn-primary" onClick={draft} disabled={busy === 'email'}>{busy === 'email' ? 'Writing…' : 'Write email'}</button>
            </div>
            {email.draft && (
              <div className="draft">
                <input value={email.draft.subject} onChange={(e) => setEmail({ ...email, draft: { ...email.draft, subject: e.target.value } })} aria-label="Subject" />
                <textarea rows="9" value={email.draft.body} onChange={(e) => setEmail({ ...email, draft: { ...email.draft, body: e.target.value } })} aria-label="Body" />
                <div className="draft-actions">
                  <button className="btn" onClick={() => { navigator.clipboard.writeText(`Subject: ${email.draft.subject}\n\n${email.draft.body}`); setCopied(true); setTimeout(() => setCopied(false), 1500); }}>{copied ? 'Copied' : 'Copy'}</button>
                  {lead.email && <a className="btn btn-primary" href={`mailto:${lead.email}?subject=${encodeURIComponent(email.draft.subject)}&body=${encodeURIComponent(email.draft.body)}`}>Open in mail app</a>}
                </div>
              </div>
            )}
          </section>
        </div>

        <aside className="detail-side">
          <section className="panel">
            <h2>Details</h2>
            <dl className="facts">
              <dt>Deal value</dt><dd>{inr(lead.value)}</dd>
              <dt>Budget</dt><dd>{lead.budget}</dd>
              <dt>Source</dt><dd>{lead.source}</dd>
              <dt>Email</dt><dd>{lead.email ? <a href={`mailto:${lead.email}`}>{lead.email}</a> : '–'}</dd>
              <dt>Phone</dt><dd>{lead.phone ? <a href={`tel:${lead.phone}`}>{lead.phone}</a> : '–'}</dd>
              <dt>Last contact</dt><dd>{lead.lastContactedAt ? timeAgo(lead.lastContactedAt) : '–'}</dd>
              <dt>Added</dt><dd>{fmtDate(lead.createdAt)}</dd>
            </dl>
          </section>

          <section className="panel">
            <h2>Tasks</h2>
            <form onSubmit={addTask} className="mini-task">
              <input required placeholder="Call about pricing" value={task.title} onChange={(e) => setTask({ ...task, title: e.target.value })} />
              <div className="mini-row">
                <input required type="date" value={task.dueDate} onChange={(e) => setTask({ ...task, dueDate: e.target.value })} aria-label="Due date" />
                <button className="btn btn-primary" disabled={busy === 'task'}>Add</button>
              </div>
            </form>
            <ul className="checklist">
              {tasks.map((t) => (
                <li key={t._id} className={t.done ? 'done' : ''}>
                  <label><input type="checkbox" checked={t.done} onChange={() => toggleTask(t)} /> {t.title}</label>
                  <time>{fmtDate(t.dueDate)}</time>
                </li>
              ))}
              {tasks.length === 0 && <li className="muted">No tasks for this lead.</li>}
            </ul>
          </section>

          <section className="panel">
            <h2>History</h2>
            <ul className="timeline">
              {activity.map((a) => <li key={a._id}><span>{a.message}</span><time>{timeAgo(a.createdAt)}</time></li>)}
            </ul>
            {activity.length === 0 && <p className="muted small">Stage changes, notes and emails will show here.</p>}
          </section>
        </aside>
      </div>

      {editing && (
        <Modal title={`Edit ${lead.name}`} onClose={() => setEditing(false)}>
          <LeadForm initial={lead} onSubmit={save} submitLabel="Save changes" busy={busy === 'save'} />
        </Modal>
      )}
    </div>
  );
}
