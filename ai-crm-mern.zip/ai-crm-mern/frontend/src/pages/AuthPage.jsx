import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { errMsg } from '../api';

export default function AuthPage({ mode }) {
  const isLogin = mode === 'login';
  const { signIn } = useAuth();
  const nav = useNavigate();
  const [f, setF] = useState({ name: '', company: '', email: isLogin ? 'demo@crm.com' : '', password: isLogin ? 'demo123' : '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      await signIn(isLogin ? 'login' : 'register', f);
      nav('/');
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="auth">
      <section className="auth-side">
        <div className="brand"><span className="brand-mark">L</span><span>Leadwise</span></div>
        <h1>Know which lead to call next.</h1>
        <p>Leadwise scores every lead, reads the mood of your notes, drafts follow-up emails and answers questions about your pipeline.</p>
        <ul className="auth-demo">
          <li><span className="score-dot hot" /> Rohit Sharma, Sharma Textiles <b>86</b></li>
          <li><span className="score-dot warm" /> Neha Joshi, Pune EdTech <b>54</b></li>
          <li><span className="score-dot cold" /> Manish Tiwari, Tiwari Caterers <b>18</b></li>
        </ul>
      </section>
      <section className="auth-form-wrap">
        <form className="auth-form" onSubmit={submit}>
          <h2>{isLogin ? 'Sign in' : 'Create your account'}</h2>
          {isLogin && <p className="muted">Demo login is filled in. Run <code>npm run seed</code> in the backend first.</p>}
          {!isLogin && (
            <>
              <label>Your name<input required value={f.name} onChange={set('name')} /></label>
              <label>Company<input value={f.company} onChange={set('company')} /></label>
            </>
          )}
          <label>Email<input type="email" required value={f.email} onChange={set('email')} /></label>
          <label>Password<input type="password" required minLength={6} value={f.password} onChange={set('password')} /></label>
          {error && <p className="error">{error}</p>}
          <button className="btn btn-primary btn-block" disabled={busy}>{busy ? 'Please wait…' : isLogin ? 'Sign in' : 'Create account'}</button>
          <p className="muted center">
            {isLogin ? <>New here? <Link to="/register">Create an account</Link></> : <>Have an account? <Link to="/login">Sign in</Link></>}
          </p>
        </form>
      </section>
    </div>
  );
}
