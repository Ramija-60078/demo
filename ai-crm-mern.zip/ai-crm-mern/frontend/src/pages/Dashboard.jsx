import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import api, { compactInr, errMsg, fmtDate, inr, timeAgo } from '../api';
import ScoreBar from '../components/ScoreBar';
import { useAuth } from '../context/AuthContext';

const STAGE_COLORS = { New: '#9AA8B2', Contacted: '#7FA7A0', Qualified: '#4F8C82', Proposal: '#2E7468', Negotiation: '#0E5A4F', Won: '#D98E04', Lost: '#C9CFCD' };

export default function Dashboard() {
  const { user } = useAuth();
  const [d, setD] = useState(null);
  const [error, setError] = useState('');
  const [scoring, setScoring] = useState(false);

  const load = () => api.get('/dashboard').then((r) => setD(r.data)).catch((e) => setError(errMsg(e)));
  useEffect(() => { load(); }, []);

  const scoreAll = async () => {
    setScoring(true);
    await api.post('/ai/score-all').catch(() => {});
    await load();
    setScoring(false);
  };

  if (error) return <p className="error">{error}</p>;
  if (!d) return <div className="loading">Loading dashboard…</div>;
  const s = d.stats;
  const hour = new Date().getHours();
  const greet = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <h1>{greet}, {user.name.split(' ')[0]}</h1>
          <p className="muted">
            {s.hot ? `${s.hot} hot lead${s.hot > 1 ? 's' : ''} waiting` : 'No hot leads right now'}
            {s.overdueTasks ? `, ${s.overdueTasks} overdue task${s.overdueTasks > 1 ? 's' : ''}` : ''}.
          </p>
        </div>
        <div className="head-actions">
          <span className={`ai-chip ai-${d.aiProvider}`}>AI: {d.aiProvider === 'offline' ? 'built-in engine' : d.aiProvider}</span>
          <button className="btn" onClick={scoreAll} disabled={scoring}>{scoring ? 'Scoring…' : 'Score all leads'}</button>
        </div>
      </div>

      <section className="kpis">
        <div className="kpi kpi-lead">
          <span>AI forecast</span>
          <strong>{inr(s.forecast)}</strong>
          <small>Open pipeline {inr(s.openValue)}, weighted by each lead's score</small>
        </div>
        <div className="kpi"><span>Open leads</span><strong>{s.open}</strong><small>{s.total} in total</small></div>
        <div className="kpi"><span>Won</span><strong>{compactInr(s.wonValue)}</strong><small>{s.won} deals</small></div>
        <div className="kpi"><span>Win rate</span><strong>{s.winRate}%</strong><small>of {s.closed} closed</small></div>
      </section>

      <div className="grid-2">
        <section className="panel">
          <h2>Leads and revenue, last 6 months</h2>
          <div className="chart">
            <ResponsiveContainer width="100%" height={240}>
              <AreaChart data={s.trend} margin={{ left: -10, right: 8, top: 8 }}>
                <defs>
                  <linearGradient id="g1" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0" stopColor="#0E5A4F" stopOpacity={0.25} />
                    <stop offset="1" stopColor="#0E5A4F" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke="var(--line)" vertical={false} />
                <XAxis dataKey="month" tickLine={false} axisLine={false} fontSize={12} />
                <YAxis yAxisId="l" tickLine={false} axisLine={false} fontSize={12} allowDecimals={false} />
                <YAxis yAxisId="r" orientation="right" tickLine={false} axisLine={false} fontSize={12} tickFormatter={compactInr} />
                <Tooltip formatter={(v, n) => (n === 'won' ? [inr(v), 'Won value'] : [v, 'New leads'])} />
                <Area yAxisId="l" type="monotone" dataKey="leads" stroke="#0E5A4F" strokeWidth={2} fill="url(#g1)" />
                <Area yAxisId="r" type="monotone" dataKey="won" stroke="#D98E04" strokeWidth={2} fill="none" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <div className="legend"><span className="lg lg-pine" />New leads <span className="lg lg-amber" />Won value</div>
        </section>

        <section className="panel">
          <h2>What the AI noticed</h2>
          <ul className="insights">
            {d.insights.map((i, k) => <li key={k} className={`insight insight-${i.tone}`}>{i.text}</li>)}
          </ul>
          <Link to="/assistant" className="btn btn-ghost">Ask the assistant</Link>
        </section>
      </div>

      <div className="grid-2">
        <section className="panel">
          <h2>Pipeline by stage</h2>
          <div className="chart">
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={s.byStatus} layout="vertical" margin={{ left: 20, right: 16 }}>
                <XAxis type="number" hide />
                <YAxis type="category" dataKey="_id" tickLine={false} axisLine={false} fontSize={12} width={82} />
                <Tooltip formatter={(v, n, p) => [`${v} leads, ${inr(p.payload.value)}`, 'Stage']} cursor={{ fill: 'var(--mint)' }} />
                <Bar dataKey="count" radius={[0, 4, 4, 0]} barSize={16}>
                  {s.byStatus.map((e) => <Cell key={e._id} fill={STAGE_COLORS[e._id]} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </section>

        <section className="panel">
          <div className="panel-head"><h2>Call these first</h2><Link to="/leads">All leads</Link></div>
          {d.topLeads.length === 0 && <p className="muted">No open leads. <Link to="/leads">Add your first lead</Link>.</p>}
          <ul className="rows">
            {d.topLeads.map((l) => (
              <li key={l._id}>
                <Link to={`/leads/${l._id}`} className="row-link">
                  <div className="row-main">
                    <strong>{l.name}</strong>
                    <span className="muted">{l.company}, {compactInr(l.value)}</span>
                  </div>
                  <ScoreBar score={l.ai?.score} label={l.ai?.label} />
                </Link>
              </li>
            ))}
          </ul>
        </section>
      </div>

      <div className="grid-2">
        <section className="panel">
          <div className="panel-head"><h2>Upcoming tasks</h2><Link to="/tasks">All tasks</Link></div>
          {d.upcomingTasks.length === 0 && <p className="muted">Nothing scheduled.</p>}
          <ul className="rows">
            {d.upcomingTasks.map((t) => {
              const overdue = new Date(t.dueDate) < new Date(new Date().setHours(0, 0, 0, 0));
              return (
                <li key={t._id} className="row-plain">
                  <span>{t.title}</span>
                  <span className={overdue ? 'due overdue' : 'due'}>{overdue ? 'Overdue, ' : ''}{fmtDate(t.dueDate)}</span>
                </li>
              );
            })}
          </ul>
        </section>
        <section className="panel">
          <h2>Recent activity</h2>
          <ul className="timeline">
            {d.activity.map((a) => (
              <li key={a._id}><span>{a.message}</span><time>{timeAgo(a.createdAt)}</time></li>
            ))}
          </ul>
        </section>
      </div>
    </div>
  );
}
