import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api, { SOURCES, STATUSES, errMsg, inr, timeAgo } from '../api';
import Modal from '../components/Modal';
import LeadForm from '../components/LeadForm';
import ScoreBar from '../components/ScoreBar';
import StatusPill from '../components/StatusPill';

export default function Leads() {
  const nav = useNavigate();
  const [leads, setLeads] = useState(null);
  const [filters, setFilters] = useState({ search: '', status: '', source: '', label: '', sort: '-ai.score' });
  const [adding, setAdding] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    const t = setTimeout(() => {
      const params = Object.fromEntries(Object.entries(filters).filter(([, v]) => v));
      api.get('/leads', { params }).then((r) => setLeads(r.data)).catch((e) => setError(errMsg(e)));
    }, 250);
    return () => clearTimeout(t);
  }, [filters]);

  const set = (k) => (e) => setFilters({ ...filters, [k]: e.target.value });

  const create = async (body) => {
    setBusy(true);
    try {
      const { data } = await api.post('/leads', body);
      setAdding(false);
      nav(`/leads/${data._id}`);
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setBusy(false);
    }
  };

  const exportCsv = () => {
    const head = ['Name', 'Company', 'Email', 'Phone', 'Source', 'Stage', 'Value', 'AI score', 'AI label'];
    const rows = leads.map((l) => [l.name, l.company, l.email, l.phone, l.source, l.status, l.value, l.ai?.score, l.ai?.label]);
    const csv = [head, ...rows].map((r) => r.map((c) => `"${String(c ?? '').replace(/"/g, '""')}"`).join(',')).join('\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
    a.download = 'leads.csv';
    a.click();
  };

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <h1>Leads</h1>
          <p className="muted">{leads ? `${leads.length} shown, sorted by ${filters.sort === '-ai.score' ? 'AI score' : 'your choice'}` : ' '}</p>
        </div>
        <div className="head-actions">
          <button className="btn" onClick={exportCsv} disabled={!leads?.length}>Export CSV</button>
          <button className="btn btn-primary" onClick={() => setAdding(true)}>Add lead</button>
        </div>
      </div>

      <div className="filters">
        <input className="search" placeholder="Search name, company, email or phone" value={filters.search} onChange={set('search')} />
        <select value={filters.status} onChange={set('status')} aria-label="Stage"><option value="">All stages</option>{STATUSES.map((s) => <option key={s}>{s}</option>)}</select>
        <select value={filters.source} onChange={set('source')} aria-label="Source"><option value="">All sources</option>{SOURCES.map((s) => <option key={s}>{s}</option>)}</select>
        <select value={filters.label} onChange={set('label')} aria-label="Temperature"><option value="">Hot, warm and cold</option><option>Hot</option><option>Warm</option><option>Cold</option></select>
        <select value={filters.sort} onChange={set('sort')} aria-label="Sort">
          <option value="-ai.score">Highest AI score</option>
          <option value="-value">Highest value</option>
          <option value="-updatedAt">Recently updated</option>
          <option value="name">Name A–Z</option>
        </select>
      </div>

      {error && <p className="error">{error}</p>}
      {!leads ? <div className="loading">Loading leads…</div> : leads.length === 0 ? (
        <div className="empty">
          <p>No leads match these filters.</p>
          <button className="btn btn-primary" onClick={() => setAdding(true)}>Add a lead</button>
        </div>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr><th>Lead</th><th>Stage</th><th>Source</th><th className="num">Value</th><th>AI score</th><th>Updated</th></tr>
            </thead>
            <tbody>
              {leads.map((l) => (
                <tr key={l._id} onClick={() => nav(`/leads/${l._id}`)}>
                  <td>
                    <Link to={`/leads/${l._id}`} onClick={(e) => e.stopPropagation()} className="lead-name">{l.name}</Link>
                    <div className="muted small">{[l.jobTitle, l.company].filter(Boolean).join(', ')}</div>
                  </td>
                  <td><StatusPill status={l.status} /></td>
                  <td>{l.source}</td>
                  <td className="num">{inr(l.value)}</td>
                  <td><ScoreBar score={l.ai?.score} label={l.ai?.label} /></td>
                  <td className="muted">{timeAgo(l.updatedAt)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {adding && (
        <Modal title="Add lead" onClose={() => setAdding(false)}>
          <LeadForm onSubmit={create} busy={busy} />
        </Modal>
      )}
    </div>
  );
}
