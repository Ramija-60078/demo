import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api, { STATUSES, compactInr, errMsg } from '../api';
import ScoreBar from '../components/ScoreBar';

export default function Pipeline() {
  const [leads, setLeads] = useState(null);
  const [dragId, setDragId] = useState(null);
  const [over, setOver] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    api.get('/leads', { params: { sort: '-ai.score' } }).then((r) => setLeads(r.data)).catch((e) => setError(errMsg(e)));
  }, []);

  const move = async (id, status) => {
    const prev = leads;
    setLeads(leads.map((l) => (l._id === id ? { ...l, status } : l)));
    try {
      const { data } = await api.patch(`/leads/${id}/status`, { status });
      setLeads((ls) => ls.map((l) => (l._id === id ? data : l)));
    } catch (e) {
      setLeads(prev);
      setError(errMsg(e));
    }
  };

  if (!leads) return error ? <p className="error">{error}</p> : <div className="loading">Loading pipeline…</div>;

  return (
    <div className="page page-wide">
      <div className="page-head">
        <div>
          <h1>Pipeline</h1>
          <p className="muted">Drag a card to move a lead to another stage. The AI score updates after each move.</p>
        </div>
      </div>
      {error && <p className="error">{error}</p>}
      <div className="board">
        {STATUSES.map((s) => {
          const col = leads.filter((l) => l.status === s);
          const total = col.reduce((a, l) => a + (l.value || 0), 0);
          return (
            <section
              key={s}
              className={`column col-${s.toLowerCase()} ${over === s ? 'over' : ''}`}
              onDragOver={(e) => { e.preventDefault(); setOver(s); }}
              onDragLeave={() => setOver(null)}
              onDrop={() => { setOver(null); if (dragId) move(dragId, s); setDragId(null); }}
            >
              <header>
                <h2>{s}</h2>
                <span>{col.length}, {compactInr(total)}</span>
              </header>
              <div className="cards">
                {col.map((l) => (
                  <article
                    key={l._id}
                    className="card"
                    draggable
                    onDragStart={() => setDragId(l._id)}
                    onDragEnd={() => setDragId(null)}
                  >
                    <Link to={`/leads/${l._id}`}><strong>{l.name}</strong></Link>
                    <span className="muted small">{l.company}</span>
                    <div className="card-foot">
                      <span className="small">{compactInr(l.value)}</span>
                      <ScoreBar score={l.ai?.score} label={l.ai?.label} />
                    </div>
                    <select className="card-move" value={l.status} onChange={(e) => move(l._id, e.target.value)} aria-label={`Move ${l.name}`}>
                      {STATUSES.map((x) => <option key={x}>{x}</option>)}
                    </select>
                  </article>
                ))}
                {col.length === 0 && <p className="col-empty">Drop leads here</p>}
              </div>
            </section>
          );
        })}
      </div>
    </div>
  );
}
