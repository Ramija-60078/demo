# Leadwise – AI CRM Dashboard (MERN)

A full-stack Customer Relationship Management dashboard built with **MongoDB, Express, React and Node.js**, with AI features for lead scoring, note sentiment, email writing and a chat assistant that answers questions about your sales data.

The AI works **with or without an API key**. With no key, a built-in rule-based engine runs everything offline. Add a free Google Gemini key (or an OpenAI key) and the same features switch to a real LLM, falling back to the offline engine if the call fails.

## Features

| Module | What it does |
|---|---|
| Authentication | Register and sign in with JWT tokens and bcrypt-hashed passwords |
| Dashboard | AI revenue forecast, open leads, won value, win rate, 6-month trend chart, pipeline by stage, AI insights, top leads, upcoming tasks, recent activity |
| Leads | Add, edit, delete, search, filter by stage/source/temperature, sort by AI score or value, export to CSV |
| AI lead scoring | Scores each lead 0–100 and labels it Hot, Warm or Cold, with reasons and a recommended next step |
| Notes + sentiment | Every note is tagged positive, neutral or negative automatically, and the score updates |
| AI email writer | Drafts follow-up, introduction, meeting, proposal and thank-you emails in a chosen tone |
| Pipeline | Kanban board with drag and drop between stages (dropdown on mobile) |
| Tasks | Calls, emails and meetings linked to leads, grouped into overdue, today and later |
| AI assistant | Chat that answers "Who should I call today?", "What is my forecast?", "Which leads are going cold?" and more from live CRM data |

## Tech stack

- **Frontend:** React 18, Vite, React Router, Recharts, Axios, plain CSS (responsive)
- **Backend:** Node.js, Express, Mongoose, JWT, bcryptjs
- **Database:** MongoDB (local or MongoDB Atlas)
- **AI:** Google Gemini or OpenAI (optional), plus a built-in offline engine

## Folder structure

```
ai-crm-mern/
├── backend/
│   ├── config/db.js            MongoDB connection
│   ├── middleware/auth.js      JWT protection
│   ├── models/                 User, Lead, Task, Activity
│   ├── routes/                 auth, leads, tasks, dashboard, ai
│   ├── services/aiService.js   AI scoring, sentiment, email, assistant, insights
│   ├── services/stats.js       Dashboard metrics and forecast
│   ├── seed.js                 Demo data
│   └── server.js
└── frontend/
    └── src/
        ├── components/         Layout, ScoreBar, StatusPill, Modal, LeadForm
        ├── context/            AuthContext
        ├── pages/              AuthPage, Dashboard, Leads, LeadDetail, Pipeline, Tasks, Assistant
        ├── api.js
        └── index.css
```

## Setup

**Requirements:** Node.js 18 or newer, and MongoDB (install MongoDB Community Server locally, or create a free cluster on MongoDB Atlas).

### 1. Backend

```bash
cd backend
npm install
cp .env.example .env        # on Windows: copy .env.example .env
```

Edit `.env`:
- `MONGO_URI` – keep the local default, or paste your Atlas connection string
- `JWT_SECRET` – any long random text
- `GEMINI_API_KEY` – optional, free from https://aistudio.google.com/app/apikey

Load demo data and start the API:

```bash
npm run seed     # creates demo@crm.com / demo123 with 24 leads and tasks
npm run dev      # API on http://localhost:5000
```

### 2. Frontend

In a second terminal:

```bash
cd frontend
npm install
npm run dev      # app on http://localhost:5173
```

Open http://localhost:5173 and sign in with **demo@crm.com / demo123**.

### Production build (single server)

```bash
cd frontend && npm run build
cd ../backend && npm start     # serves the React build and API on port 5000
```

## How the AI works

**Lead scoring (offline engine).** Points are added for pipeline stage, budget, lead source quality, deal value, whether the contact is a decision maker, complete contact details and positive notes. Points are removed for negative notes and for no contact in over 14 days. The total is clamped to 0–100: 65+ is Hot, 40–64 is Warm, below 40 is Cold. Every score shows its reasons, so the result is explainable.

**Lead scoring (LLM mode).** The lead's details and last five notes are sent to Gemini/OpenAI with the offline score as a reference. The model returns JSON with score, label, reasons and next action.

**Forecast.** Each open lead's value is multiplied by its AI score as a probability (score 80 means 80%), and the results are summed. This is a weighted pipeline forecast.

**Sentiment.** Offline mode uses a keyword lexicon with negation handling ("not interested" is negative). LLM mode classifies the note directly.

**Assistant.** The backend builds a compact snapshot of the user's leads, tasks and stats and either matches the question to a known intent (offline) or sends the snapshot and question to the LLM.

## API reference

All routes except auth need the header `Authorization: Bearer <token>`.

| Method | Route | Purpose |
|---|---|---|
| POST | /api/auth/register | Create account |
| POST | /api/auth/login | Sign in |
| GET | /api/auth/me | Current user |
| GET | /api/leads | List leads (`search`, `status`, `source`, `label`, `sort`) |
| POST | /api/leads | Create lead (auto-scored) |
| GET | /api/leads/:id | Lead with tasks and history |
| PUT | /api/leads/:id | Update lead |
| PATCH | /api/leads/:id/status | Move stage (pipeline) |
| DELETE | /api/leads/:id | Delete lead and its tasks |
| POST | /api/leads/:id/notes | Add note (auto sentiment) |
| GET/POST/PUT/DELETE | /api/tasks | Task CRUD |
| GET | /api/dashboard | Stats, insights, top leads, activity |
| GET | /api/ai/status | Which AI provider is active |
| POST | /api/ai/score/:id | Re-score one lead |
| POST | /api/ai/score-all | Re-score all leads |
| POST | /api/ai/email | Draft an email `{ leadId, purpose, tone }` |
| POST | /api/ai/chat | Ask the assistant `{ question }` |
| POST | /api/ai/sentiment | Classify text `{ text }` |

## Troubleshooting

- **"Could not connect to MongoDB"** – start MongoDB (`mongod`) or check the Atlas connection string and that your IP is allowed in Atlas Network Access.
- **Login fails with the demo account** – run `npm run seed` in the backend.
- **"Could not reach the server"** in the app – the backend is not running on port 5000.
- **AI answers look rule-based** – no API key is set, or the key is invalid. The dashboard chip shows which engine is active.

## Ideas for extension

- Role-based access (admin sees all users' leads)
- Email sending with Nodemailer and open tracking
- WhatsApp follow-ups via the WhatsApp Business API
- Import leads from CSV or Google Sheets
- Train a logistic regression model on won/lost history to replace the rule-based scorer
