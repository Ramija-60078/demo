/**
 * Seeds a demo account with realistic sample data.
 * Run: npm run seed
 * Login: demo@crm.com / demo123
 */
require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('./config/db');
const User = require('./models/User');
const Lead = require('./models/Lead');
const Task = require('./models/Task');
const Activity = require('./models/Activity');
const { scoreLeadOffline, analyzeSentiment } = require('./services/aiService');

const people = [
  ['Rohit Sharma', 'Sharma Textiles', 'Owner', 'Referral', 'Negotiation', 650000, 'High'],
  ['Priya Mehta', 'UrbanNest Interiors', 'Founder', 'Google Ads', 'Proposal', 240000, 'Medium'],
  ['Arjun Nair', 'Kochi Spice Exports', 'Director', 'LinkedIn', 'Qualified', 380000, 'High'],
  ['Sneha Gupta', 'Bloom Skincare', 'Marketing Manager', 'Meta Ads', 'Contacted', 90000, 'Medium'],
  ['Vikram Singh', 'Singh Logistics', 'CEO', 'Event', 'Won', 820000, 'High'],
  ['Ananya Iyer', 'Chennai Dental Care', 'Owner', 'Website', 'New', 60000, 'Low'],
  ['Karan Malhotra', 'FitHub Gyms', 'Head of Growth', 'Google Ads', 'Proposal', 175000, 'Medium'],
  ['Neha Joshi', 'Pune EdTech', 'Co-founder', 'Referral', 'Qualified', 300000, 'Medium'],
  ['Amit Verma', 'Verma Hardware', 'Owner', 'Cold Call', 'Contacted', 45000, 'Low'],
  ['Divya Reddy', 'Hyderabad Realty', 'VP Sales', 'LinkedIn', 'Negotiation', 520000, 'High'],
  ['Rahul Kapoor', 'Kapoor Jewellers', 'Partner', 'Website', 'Lost', 200000, 'Medium'],
  ['Pooja Agarwal', 'Organic Basket', 'Founder', 'Meta Ads', 'New', 70000, 'Unknown'],
  ['Sanjay Patel', 'Patel Pharma', 'Director', 'Event', 'Won', 450000, 'High'],
  ['Meera Krishnan', 'Tiny Toes Preschool', 'Principal', 'Website', 'Contacted', 55000, 'Low'],
  ['Aditya Rao', 'CloudKart', 'CTO', 'LinkedIn', 'Qualified', 410000, 'High'],
  ['Kavya Menon', 'Menon Ayurveda', 'Owner', 'Google Ads', 'New', 120000, 'Medium'],
  ['Harsh Vardhan', 'Vardhan Motors', 'General Manager', 'Referral', 'Proposal', 360000, 'Medium'],
  ['Ishita Bose', 'Kolkata Crafts', 'Founder', 'Meta Ads', 'Lost', 80000, 'Low'],
  ['Manish Tiwari', 'Tiwari Caterers', 'Owner', 'Cold Call', 'New', 40000, 'Unknown'],
  ['Ritu Saxena', 'Saxena Law Associates', 'Partner', 'Referral', 'Won', 260000, 'Medium'],
  ['Nikhil Jain', 'Jain Solar', 'CEO', 'Google Ads', 'Qualified', 700000, 'High'],
  ['Tanvi Deshpande', 'StyleStreet', 'Ecommerce Lead', 'Meta Ads', 'Contacted', 150000, 'Medium'],
  ['Gaurav Chauhan', 'Chauhan Builders', 'Director', 'Event', 'Proposal', 900000, 'High'],
  ['Simran Kaur', 'Punjab Dairy Co', 'Owner', 'Website', 'Lost', 110000, 'Low'],
];

const noteBank = {
  positive: ['Very interested in the demo, wants pricing by Friday.', 'Budget approved by management. Ready to move ahead.', 'Loved the case study, asked for a call with the team.'],
  neutral: ['Asked for more details on timeline.', 'Shared company profile over email.', 'Will discuss internally and revert.'],
  negative: ['Says our quote is expensive compared to a competitor.', 'No response to last two calls.', 'Wants to delay the project to next quarter.'],
};

const daysAgo = (n) => new Date(Date.now() - n * 86400000);
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

(async () => {
  await connectDB();
  await Promise.all([User.deleteMany({ email: 'demo@crm.com' })]);
  const user = await User.create({ name: 'Demo User', email: 'demo@crm.com', password: 'demo123', company: 'Demo Agency' });
  await Promise.all([Lead.deleteMany({ owner: user._id }), Task.deleteMany({ owner: user._id }), Activity.deleteMany({ owner: user._id })]);

  const docs = [];
  for (const [i, p] of people.entries()) {
    const [name, company, jobTitle, source, status, value, budget] = p;
    const created = daysAgo(5 + Math.floor(Math.random() * 170));
    const updated = new Date(Math.min(Date.now(), created.getTime() + Math.random() * 40 * 86400000));
    const mood = ['Won', 'Negotiation', 'Proposal'].includes(status) ? 'positive' : status === 'Lost' ? 'negative' : pick(['positive', 'neutral', 'negative', 'neutral']);
    const notes = [];
    for (let k = 0; k < 1 + (i % 3); k++) {
      const text = pick(noteBank[k === 0 ? mood : pick(['neutral', mood])]);
      notes.push({ _id: new mongoose.Types.ObjectId(), text, sentiment: await analyzeSentiment(text), createdAt: updated, updatedAt: updated });
    }
    const lead = {
      _id: new mongoose.Types.ObjectId(),
      owner: user._id, name, company, jobTitle, source, status, value, budget,
      email: `${name.split(' ')[0].toLowerCase()}@${company.toLowerCase().replace(/[^a-z]/g, '')}.in`,
      phone: `+91 9${String(800000000 + i * 7919123).slice(0, 9)}`,
      tags: [], notes, lastContactedAt: updated, createdAt: created, updatedAt: updated,
    };
    lead.ai = { ...scoreLeadOffline(lead), scoredAt: new Date() };
    docs.push(lead);
  }
  await Lead.collection.insertMany(docs);

  const taskTypes = ['Call', 'Email', 'Meeting', 'Follow-up'];
  const tasks = docs
    .filter((l) => !['Won', 'Lost'].includes(l.status))
    .slice(0, 14)
    .map((l, i) => ({
      owner: user._id,
      lead: l._id,
      title: `${taskTypes[i % 4]} ${l.name.split(' ')[0]} (${l.company})`,
      type: taskTypes[i % 4],
      dueDate: daysAgo(3 - i),
      priority: l.ai.label === 'Hot' ? 'High' : l.ai.label === 'Warm' ? 'Medium' : 'Low',
      done: i % 5 === 0,
    }));
  await Task.insertMany(tasks);

  await Activity.insertMany(
    docs.slice(0, 10).map((l) => ({ owner: user._id, lead: l._id, kind: 'created', message: `Added lead ${l.name}` }))
  );

  console.log(`Seeded ${docs.length} leads and ${tasks.length} tasks.\nLogin: demo@crm.com / demo123`);
  await mongoose.disconnect();
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
