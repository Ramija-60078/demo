const router = require('express').Router();
const Lead = require('../models/Lead');
const Task = require('../models/Task');
const Activity = require('../models/Activity');
const ai = require('../services/aiService');

const log = (req, lead, kind, message) => Activity.create({ owner: req.user._id, lead: lead?._id, kind, message });

async function findOwned(req, res) {
  const lead = await Lead.findOne({ _id: req.params.id, owner: req.user._id });
  if (!lead) res.status(404).json({ message: 'Lead not found.' });
  return lead;
}

// GET /api/leads?search=&status=&source=&label=&sort=
router.get('/', async (req, res) => {
  const { search, status, source, label, sort = '-updatedAt' } = req.query;
  const q = { owner: req.user._id };
  if (status) q.status = status;
  if (source) q.source = source;
  if (label) q['ai.label'] = label;
  if (search) {
    const rx = new RegExp(search.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
    q.$or = [{ name: rx }, { company: rx }, { email: rx }, { phone: rx }];
  }
  const leads = await Lead.find(q).sort(sort).lean();
  res.json(leads);
});

router.post('/', async (req, res) => {
  const lead = new Lead({ ...req.body, owner: req.user._id, notes: [] });
  Object.assign(lead.ai, await ai.scoreLead(lead), { scoredAt: new Date() });
  await lead.save();
  await log(req, lead, 'created', `Added lead ${lead.name}`);
  res.status(201).json(lead);
});

router.get('/:id', async (req, res) => {
  const lead = await findOwned(req, res);
  if (!lead) return;
  const [tasks, activity] = await Promise.all([
    Task.find({ lead: lead._id }).sort({ dueDate: 1 }),
    Activity.find({ lead: lead._id }).sort({ createdAt: -1 }).limit(30),
  ]);
  res.json({ lead, tasks, activity });
});

router.put('/:id', async (req, res) => {
  const lead = await findOwned(req, res);
  if (!lead) return;
  const prevStatus = lead.status;
  const { notes, owner, ai: _ai, ...updates } = req.body;
  Object.assign(lead, updates);
  if (updates.status && updates.status !== prevStatus) {
    lead.lastContactedAt = new Date();
    await log(req, lead, 'status', `${lead.name}: ${prevStatus} → ${updates.status}`);
  }
  Object.assign(lead.ai, await ai.scoreLead(lead), { scoredAt: new Date() });
  await lead.save();
  res.json(lead);
});

// PATCH /api/leads/:id/status – used by the pipeline drag & drop
router.patch('/:id/status', async (req, res) => {
  const lead = await findOwned(req, res);
  if (!lead) return;
  const prev = lead.status;
  lead.status = req.body.status;
  lead.lastContactedAt = new Date();
  Object.assign(lead.ai, ai.scoreLeadOffline(lead), { scoredAt: new Date() });
  await lead.save();
  await log(req, lead, 'status', `${lead.name}: ${prev} → ${lead.status}`);
  res.json(lead);
});

router.delete('/:id', async (req, res) => {
  const lead = await findOwned(req, res);
  if (!lead) return;
  await Promise.all([lead.deleteOne(), Task.deleteMany({ lead: lead._id }), Activity.deleteMany({ lead: lead._id })]);
  res.json({ message: 'Lead deleted.' });
});

// POST /api/leads/:id/notes  { text }  – note is auto-tagged with AI sentiment
router.post('/:id/notes', async (req, res) => {
  const lead = await findOwned(req, res);
  if (!lead) return;
  if (!req.body.text?.trim()) return res.status(400).json({ message: 'Write a note first.' });
  const sentiment = await ai.analyzeSentiment(req.body.text);
  lead.notes.push({ text: req.body.text.trim(), sentiment });
  lead.lastContactedAt = new Date();
  Object.assign(lead.ai, await ai.scoreLead(lead), { scoredAt: new Date() });
  await lead.save();
  await log(req, lead, 'note', `Note added (${sentiment})`);
  res.json(lead);
});

module.exports = router;
