const router = require('express').Router();
const Task = require('../models/Task');
const Activity = require('../models/Activity');

router.get('/', async (req, res) => {
  const q = { owner: req.user._id };
  if (req.query.done !== undefined) q.done = req.query.done === 'true';
  const tasks = await Task.find(q).populate('lead', 'name company').sort({ done: 1, dueDate: 1 });
  res.json(tasks);
});

router.post('/', async (req, res) => {
  const { title, dueDate } = req.body;
  if (!title || !dueDate) return res.status(400).json({ message: 'Title and due date are required.' });
  const task = await Task.create({ ...req.body, lead: req.body.lead || undefined, owner: req.user._id });
  await Activity.create({ owner: req.user._id, lead: task.lead, kind: 'task', message: `Task created: ${task.title}` });
  res.status(201).json(await task.populate('lead', 'name company'));
});

router.put('/:id', async (req, res) => {
  const task = await Task.findOneAndUpdate({ _id: req.params.id, owner: req.user._id }, req.body, { new: true })
    .populate('lead', 'name company');
  if (!task) return res.status(404).json({ message: 'Task not found.' });
  if (req.body.done === true) {
    await Activity.create({ owner: req.user._id, lead: task.lead?._id, kind: 'task', message: `Task completed: ${task.title}` });
  }
  res.json(task);
});

router.delete('/:id', async (req, res) => {
  const task = await Task.findOneAndDelete({ _id: req.params.id, owner: req.user._id });
  if (!task) return res.status(404).json({ message: 'Task not found.' });
  res.json({ message: 'Task deleted.' });
});

module.exports = router;
