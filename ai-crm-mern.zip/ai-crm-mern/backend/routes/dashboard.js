const router = require('express').Router();
const Activity = require('../models/Activity');
const crmContext = require('../services/stats');
const ai = require('../services/aiService');

router.get('/', async (req, res) => {
  const ctx = await crmContext(req.user._id);
  const activity = await Activity.find({ owner: req.user._id }).sort({ createdAt: -1 }).limit(12).populate('lead', 'name');
  const open = ctx.leads.filter((l) => !['Won', 'Lost'].includes(l.status));
  res.json({
    stats: ctx.stats,
    insights: ai.buildInsights(ctx),
    topLeads: [...open].sort((a, b) => (b.ai?.score || 0) - (a.ai?.score || 0)).slice(0, 5),
    upcomingTasks: ctx.tasks.filter((t) => !t.done).slice(0, 6),
    activity,
    aiProvider: ai.activeProvider(),
  });
});

module.exports = router;
