const router = require('express').Router();
const Lead = require('../models/Lead');
const Activity = require('../models/Activity');
const ai = require('../services/aiService');
const crmContext = require('../services/stats');

router.get('/status', (req, res) => res.json({ provider: ai.activeProvider() }));

// Re-score one lead
router.post('/score/:id', async (req, res) => {
  const lead = await Lead.findOne({ _id: req.params.id, owner: req.user._id });
  if (!lead) return res.status(404).json({ message: 'Lead not found.' });
  Object.assign(lead.ai, await ai.scoreLead(lead), { scoredAt: new Date() });
  await lead.save();
  await Activity.create({ owner: req.user._id, lead: lead._id, kind: 'ai', message: `AI scored ${lead.name}: ${lead.ai.score} (${lead.ai.label})` });
  res.json(lead);
});

// Re-score every lead (offline engine for speed, LLM for the first 15 when configured)
router.post('/score-all', async (req, res) => {
  const leads = await Lead.find({ owner: req.user._id });
  let i = 0;
  for (const lead of leads) {
    const result = i < 15 ? await ai.scoreLead(lead) : ai.scoreLeadOffline(lead);
    Object.assign(lead.ai, result, { scoredAt: new Date() });
    await lead.save();
    i++;
  }
  res.json({ message: `Scored ${leads.length} leads.`, count: leads.length });
});

// Draft an email  { leadId, purpose, tone }
router.post('/email', async (req, res) => {
  const lead = await Lead.findOne({ _id: req.body.leadId, owner: req.user._id });
  if (!lead) return res.status(404).json({ message: 'Choose a lead to write to.' });
  const draft = await ai.draftEmail(lead, req.body.purpose, req.body.tone, req.user.name);
  await Activity.create({ owner: req.user._id, lead: lead._id, kind: 'email', message: `AI drafted a ${req.body.purpose || 'follow-up'} email` });
  res.json(draft);
});

// Ask the CRM assistant  { question }
router.post('/chat', async (req, res) => {
  if (!req.body.question?.trim()) return res.status(400).json({ message: 'Type a question first.' });
  const ctx = await crmContext(req.user._id);
  res.json(await ai.askAssistant(req.body.question, ctx));
});

// Standalone sentiment check  { text }
router.post('/sentiment', async (req, res) => {
  res.json({ sentiment: await ai.analyzeSentiment(req.body.text || '') });
});

module.exports = router;
