/**
 * AI service for the CRM.
 *
 * Works in two modes:
 *  1. LLM mode   – if GEMINI_API_KEY or OPENAI_API_KEY is set, prompts go to that model.
 *  2. Offline    – no key needed. A rule-based engine scores leads, reads sentiment,
 *                  drafts emails and answers questions about the CRM data.
 * If an LLM call fails, every feature falls back to offline mode automatically,
 * so the project always runs in a viva / demo even without internet.
 */

const STAGE_POINTS = { New: 5, Contacted: 12, Qualified: 22, Proposal: 28, Negotiation: 33, Won: 40, Lost: 0 };
const BUDGET_POINTS = { Unknown: 0, Low: 4, Medium: 10, High: 16 };
const SOURCE_POINTS = { Referral: 12, Event: 8, LinkedIn: 7, 'Google Ads': 7, 'Meta Ads': 5, Website: 6, 'Cold Call': 2, Other: 2 };
const SENIOR_TITLES = /(ceo|cto|cfo|coo|founder|owner|director|head|vp|president|partner|manager)/i;

const POSITIVE = ['interested', 'great', 'good', 'happy', 'yes', 'ready', 'approved', 'excited', 'love', 'agree', 'budget approved', 'keen', 'urgent', 'soon', 'confirm', 'thanks', 'perfect', 'impressed', 'demo'];
const NEGATIVE = ['not interested', 'expensive', 'costly', 'no budget', 'later', 'busy', 'cancel', 'unhappy', 'angry', 'competitor', 'delay', 'problem', 'issue', 'reject', 'no response', 'ghost', 'stop', 'complain'];

/* ----------------------------- LLM plumbing ----------------------------- */

function activeProvider() {
  if (process.env.GEMINI_API_KEY) return 'gemini';
  if (process.env.OPENAI_API_KEY) return 'openai';
  return 'offline';
}

async function callLLM(system, prompt) {
  const provider = activeProvider();
  if (provider === 'gemini') {
    const model = process.env.GEMINI_MODEL || 'gemini-1.5-flash';
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${process.env.GEMINI_API_KEY}`;
    const r = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: system }] },
        contents: [{ role: 'user', parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0.4 },
      }),
    });
    if (!r.ok) throw new Error(`Gemini ${r.status}`);
    const data = await r.json();
    return data.candidates?.[0]?.content?.parts?.map((p) => p.text).join('') || '';
  }
  if (provider === 'openai') {
    const r = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${process.env.OPENAI_API_KEY}` },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || 'gpt-4o-mini',
        temperature: 0.4,
        messages: [
          { role: 'system', content: system },
          { role: 'user', content: prompt },
        ],
      }),
    });
    if (!r.ok) throw new Error(`OpenAI ${r.status}`);
    const data = await r.json();
    return data.choices?.[0]?.message?.content || '';
  }
  throw new Error('No LLM configured');
}

function parseJSON(text) {
  const clean = text.replace(/```json|```/g, '').trim();
  const start = clean.indexOf('{');
  const end = clean.lastIndexOf('}');
  return JSON.parse(clean.slice(start, end + 1));
}

/* ------------------------------ Sentiment ------------------------------- */

function sentimentOffline(text = '') {
  const t = text.toLowerCase();
  let score = 0;
  NEGATIVE.forEach((w) => { if (t.includes(w)) score -= 1; });
  // avoid double counting "not interested" as positive "interested"
  POSITIVE.forEach((w) => { if (t.includes(w) && !t.includes(`not ${w}`)) score += 1; });
  if (score > 0) return 'positive';
  if (score < 0) return 'negative';
  return 'neutral';
}

async function analyzeSentiment(text) {
  if (activeProvider() === 'offline') return sentimentOffline(text);
  try {
    const out = await callLLM(
      'You classify the sentiment of sales notes. Reply with exactly one word: positive, neutral or negative.',
      text
    );
    const word = out.trim().toLowerCase().replace(/[^a-z]/g, '');
    return ['positive', 'neutral', 'negative'].includes(word) ? word : sentimentOffline(text);
  } catch {
    return sentimentOffline(text);
  }
}

/* ----------------------------- Lead scoring ----------------------------- */

function daysSince(date) {
  if (!date) return null;
  return Math.floor((Date.now() - new Date(date).getTime()) / 86400000);
}

function nextActionFor(lead, label) {
  const idle = daysSince(lead.lastContactedAt || lead.updatedAt);
  switch (lead.status) {
    case 'New': return 'Call within 24 hours and qualify budget and timeline.';
    case 'Contacted': return idle > 5 ? 'Follow up today – no touch in over 5 days.' : 'Book a discovery meeting.';
    case 'Qualified': return 'Send a tailored proposal with pricing options.';
    case 'Proposal': return label === 'Hot' ? 'Ask for a decision date and handle final objections.' : 'Follow up on the proposal and offer a short call.';
    case 'Negotiation': return 'Share the contract and agree on a start date.';
    case 'Won': return 'Start onboarding and ask for a referral.';
    case 'Lost': return 'Add to a 90-day nurture sequence.';
    default: return 'Reach out and learn more about their needs.';
  }
}

function scoreLeadOffline(lead) {
  const reasons = [];
  let score = 0;

  score += STAGE_POINTS[lead.status] ?? 0;
  reasons.push(`Stage "${lead.status}" (+${STAGE_POINTS[lead.status] ?? 0})`);

  const b = BUDGET_POINTS[lead.budget] ?? 0;
  score += b;
  if (b) reasons.push(`${lead.budget} budget (+${b})`);

  const s = SOURCE_POINTS[lead.source] ?? 2;
  score += s;
  reasons.push(`Source ${lead.source} (+${s})`);

  if (lead.value >= 500000) { score += 10; reasons.push('Deal value above ₹5L (+10)'); }
  else if (lead.value >= 100000) { score += 6; reasons.push('Deal value above ₹1L (+6)'); }
  else if (lead.value > 0) { score += 3; reasons.push('Has a deal value (+3)'); }

  if (lead.jobTitle && SENIOR_TITLES.test(lead.jobTitle)) { score += 8; reasons.push('Talking to a decision maker (+8)'); }
  if (lead.email && lead.phone) { score += 4; reasons.push('Full contact details (+4)'); }

  const notes = lead.notes || [];
  const pos = notes.filter((n) => n.sentiment === 'positive').length;
  const neg = notes.filter((n) => n.sentiment === 'negative').length;
  if (pos) { score += Math.min(pos * 4, 10); reasons.push(`${pos} positive note(s)`); }
  if (neg) { score -= Math.min(neg * 5, 15); reasons.push(`${neg} negative note(s)`); }

  const idle = daysSince(lead.lastContactedAt || lead.updatedAt);
  if (idle !== null && idle > 14 && !['Won', 'Lost'].includes(lead.status)) {
    score -= 10; reasons.push(`No contact for ${idle} days (−10)`);
  }

  score = Math.max(0, Math.min(100, Math.round(score)));
  if (lead.status === 'Won') score = 100;
  if (lead.status === 'Lost') score = Math.min(score, 10);
  const label = score >= 65 ? 'Hot' : score >= 40 ? 'Warm' : 'Cold';

  return { score, label, reasons, nextAction: nextActionFor(lead, label), provider: 'offline' };
}

async function scoreLead(lead) {
  const base = scoreLeadOffline(lead);
  if (activeProvider() === 'offline') return base;
  try {
    const summary = {
      name: lead.name, company: lead.company, jobTitle: lead.jobTitle, source: lead.source,
      status: lead.status, value: lead.value, budget: lead.budget,
      daysSinceContact: daysSince(lead.lastContactedAt || lead.updatedAt),
      notes: (lead.notes || []).slice(-5).map((n) => n.text),
    };
    const out = await callLLM(
      'You are a B2B sales analyst. Score how likely this lead is to convert. Respond ONLY with JSON: {"score":0-100,"label":"Cold|Warm|Hot","reasons":["short reason",...max 4],"nextAction":"one sentence"}',
      `Lead data: ${JSON.stringify(summary)}\nA rule-based model gave ${base.score}. Use it as a reference.`
    );
    const j = parseJSON(out);
    const score = Math.max(0, Math.min(100, Math.round(Number(j.score))));
    if (Number.isNaN(score)) return base;
    return {
      score,
      label: ['Cold', 'Warm', 'Hot'].includes(j.label) ? j.label : base.label,
      reasons: Array.isArray(j.reasons) ? j.reasons.slice(0, 4) : base.reasons,
      nextAction: j.nextAction || base.nextAction,
      provider: activeProvider(),
    };
  } catch {
    return base;
  }
}

/* ----------------------------- Email drafts ----------------------------- */

function draftEmailOffline(lead, purpose = 'follow-up', tone = 'friendly', sender = 'Team') {
  const first = (lead.name || 'there').split(' ')[0];
  const company = lead.company ? ` at ${lead.company}` : '';
  const warm = tone === 'formal' ? `Dear ${first},` : `Hi ${first},`;
  const bodies = {
    'follow-up': {
      subject: `Following up on our conversation`,
      body: `I wanted to follow up on our last conversation about your plans${company}. Do you have 15 minutes this week to discuss the next steps? I can share a few ideas tailored to your goals.`,
    },
    introduction: {
      subject: `Quick introduction`,
      body: `I help teams like yours${company} grow with better processes and tools. I'd love to understand what you are working on this quarter and see if we can help.`,
    },
    proposal: {
      subject: `Your proposal is ready`,
      body: `As discussed, I've put together a proposal${lead.company ? ` for ${lead.company}` : ''}${lead.value ? ` with an estimated value of ₹${Number(lead.value).toLocaleString('en-IN')}` : ''}. It covers scope, timeline and pricing options. Let me know a good time to walk you through it.`,
    },
    'meeting-request': {
      subject: `Can we set up a short call?`,
      body: `Would you be open to a 20-minute call this week? I'd like to understand your requirements better and answer any questions.`,
    },
    'thank-you': {
      subject: `Thank you`,
      body: `Thank you for your time today. I've noted the points we discussed and will send the next steps shortly.`,
    },
  };
  const pick = bodies[purpose] || bodies['follow-up'];
  const close = tone === 'formal' ? 'Kind regards,' : 'Best,';
  return { subject: pick.subject, body: `${warm}\n\n${pick.body}\n\n${close}\n${sender}`, provider: 'offline' };
}

async function draftEmail(lead, purpose, tone, sender) {
  if (activeProvider() === 'offline') return draftEmailOffline(lead, purpose, tone, sender);
  try {
    const out = await callLLM(
      'You write short, specific sales emails (under 120 words). Respond ONLY with JSON: {"subject":"...","body":"..."}. Sign off with the sender name given.',
      `Purpose: ${purpose}. Tone: ${tone}. Sender: ${sender}.\nLead: ${JSON.stringify({
        name: lead.name, company: lead.company, jobTitle: lead.jobTitle, status: lead.status,
        value: lead.value, notes: (lead.notes || []).slice(-3).map((n) => n.text),
      })}`
    );
    const j = parseJSON(out);
    if (!j.subject || !j.body) throw new Error('bad shape');
    return { subject: j.subject, body: j.body, provider: activeProvider() };
  } catch {
    return draftEmailOffline(lead, purpose, tone, sender);
  }
}

/* ---------------------------- CRM assistant ----------------------------- */

const inr = (n) => `₹${Math.round(n).toLocaleString('en-IN')}`;

function assistantOffline(question, ctx) {
  const q = question.toLowerCase();
  const open = ctx.leads.filter((l) => !['Won', 'Lost'].includes(l.status));

  if (/hot|best|priority|who should i (call|contact)|focus/.test(q)) {
    const top = [...open].sort((a, b) => b.ai.score - a.ai.score).slice(0, 5);
    if (!top.length) return 'You have no open leads right now. Add a lead to get started.';
    return `Focus on these leads first:\n${top.map((l, i) => `${i + 1}. ${l.name}${l.company ? ` (${l.company})` : ''} – score ${l.ai.score}, ${l.status}. ${l.ai.nextAction || ''}`).join('\n')}`;
  }
  if (/forecast|revenue|expected|predict/.test(q)) {
    return `Weighted forecast for open deals is ${inr(ctx.stats.forecast)}, based on ${open.length} open leads and their AI scores. Won so far: ${inr(ctx.stats.wonValue)}.`;
  }
  if (/pipeline|value|worth/.test(q)) {
    const lines = ctx.stats.byStatus.map((s) => `${s._id}: ${s.count} lead(s), ${inr(s.value)}`);
    return `Pipeline breakdown:\n${lines.join('\n')}`;
  }
  if (/task|overdue|today|todo|to-do/.test(q)) {
    const overdue = ctx.tasks.filter((t) => !t.done && new Date(t.dueDate) < new Date());
    const upcoming = ctx.tasks.filter((t) => !t.done && new Date(t.dueDate) >= new Date()).slice(0, 5);
    return `You have ${overdue.length} overdue task(s)${overdue.length ? `: ${overdue.slice(0, 5).map((t) => t.title).join(', ')}` : ''}. Next up: ${upcoming.map((t) => t.title).join(', ') || 'nothing scheduled'}.`;
  }
  if (/cold|risk|stale|losing|inactive/.test(q)) {
    const stale = open.filter((l) => daysSince(l.lastContactedAt || l.updatedAt) > 14);
    return stale.length
      ? `${stale.length} lead(s) have gone quiet for over 2 weeks: ${stale.slice(0, 6).map((l) => l.name).join(', ')}. Send a follow-up or move them to nurture.`
      : 'No leads have gone quiet for more than 2 weeks. Nice work.';
  }
  if (/source|channel|where.*leads|best channel/.test(q)) {
    const lines = ctx.stats.bySource.map((s) => `${s._id}: ${s.count} lead(s), ${s.won} won`);
    return `Leads by source:\n${lines.join('\n')}`;
  }
  if (/conversion|win rate|close rate/.test(q)) {
    return `Your win rate is ${ctx.stats.winRate}% (${ctx.stats.won} won out of ${ctx.stats.closed} closed leads).`;
  }
  return `Here's a quick summary: ${ctx.leads.length} leads in total, ${open.length} open, pipeline value ${inr(ctx.stats.openValue)}, forecast ${inr(ctx.stats.forecast)}, win rate ${ctx.stats.winRate}%.\n\nTry asking: "Who should I call today?", "What is my forecast?", "Which leads are going cold?", "Show overdue tasks" or "Which source works best?"`;
}

async function askAssistant(question, ctx) {
  if (activeProvider() === 'offline') return { answer: assistantOffline(question, ctx), provider: 'offline' };
  try {
    const compact = {
      stats: ctx.stats,
      leads: ctx.leads.slice(0, 60).map((l) => ({
        name: l.name, company: l.company, status: l.status, value: l.value, source: l.source,
        score: l.ai.score, label: l.ai.label, daysSinceContact: daysSince(l.lastContactedAt || l.updatedAt),
      })),
      tasks: ctx.tasks.slice(0, 40).map((t) => ({ title: t.title, due: t.dueDate, done: t.done, priority: t.priority })),
      today: new Date().toISOString().slice(0, 10),
    };
    const answer = await callLLM(
      'You are a CRM assistant for a sales team in India. Answer using ONLY the JSON data provided. Be concise, use ₹ for money, and give actionable advice. Use plain text with short lists when helpful.',
      `CRM data: ${JSON.stringify(compact)}\n\nQuestion: ${question}`
    );
    return { answer: answer.trim(), provider: activeProvider() };
  } catch {
    return { answer: assistantOffline(question, ctx), provider: 'offline' };
  }
}

/* ------------------------------- Insights ------------------------------- */

function buildInsights(ctx) {
  const out = [];
  const open = ctx.leads.filter((l) => !['Won', 'Lost'].includes(l.status));
  const hot = open.filter((l) => l.ai.label === 'Hot');
  const stale = open.filter((l) => daysSince(l.lastContactedAt || l.updatedAt) > 14);
  const overdue = ctx.tasks.filter((t) => !t.done && new Date(t.dueDate) < new Date());

  if (hot.length) out.push({ tone: 'good', text: `${hot.length} hot lead(s) worth ${inr(hot.reduce((s, l) => s + l.value, 0))}. Contact them first.` });
  if (stale.length) out.push({ tone: 'warn', text: `${stale.length} open lead(s) have had no contact for over 14 days.` });
  if (overdue.length) out.push({ tone: 'bad', text: `${overdue.length} task(s) are overdue.` });
  const bestSource = [...ctx.stats.bySource].sort((a, b) => (b.won / (b.count || 1)) - (a.won / (a.count || 1)))[0];
  if (bestSource && bestSource.won) out.push({ tone: 'good', text: `${bestSource._id} converts best: ${bestSource.won} of ${bestSource.count} leads won.` });
  const unscored = ctx.leads.filter((l) => !l.ai.scoredAt).length;
  if (unscored) out.push({ tone: 'info', text: `${unscored} lead(s) have not been scored yet. Run "Score all leads".` });
  if (!out.length) out.push({ tone: 'info', text: 'Everything is on track. Add new leads to grow the pipeline.' });
  return out;
}

module.exports = {
  activeProvider,
  analyzeSentiment,
  scoreLead,
  scoreLeadOffline,
  draftEmail,
  askAssistant,
  buildInsights,
  daysSince,
};
