const Lead = require('../models/Lead');
const Task = require('../models/Task');

/** Collects everything the dashboard and AI assistant need for one user. */
module.exports = async function crmContext(ownerId) {
  const [leads, tasks] = await Promise.all([
    Lead.find({ owner: ownerId }).sort({ updatedAt: -1 }).lean(),
    Task.find({ owner: ownerId }).sort({ dueDate: 1 }).lean(),
  ]);

  const statuses = ['New', 'Contacted', 'Qualified', 'Proposal', 'Negotiation', 'Won', 'Lost'];
  const byStatus = statuses.map((s) => {
    const list = leads.filter((l) => l.status === s);
    return { _id: s, count: list.length, value: list.reduce((a, l) => a + (l.value || 0), 0) };
  });

  const sources = [...new Set(leads.map((l) => l.source))];
  const bySource = sources.map((s) => {
    const list = leads.filter((l) => l.source === s);
    return { _id: s, count: list.length, won: list.filter((l) => l.status === 'Won').length };
  });

  const open = leads.filter((l) => !['Won', 'Lost'].includes(l.status));
  const won = leads.filter((l) => l.status === 'Won');
  const closed = leads.filter((l) => ['Won', 'Lost'].includes(l.status));

  // Monthly trend for the last 6 months: new leads and won value
  const months = [];
  for (let i = 5; i >= 0; i--) {
    const d = new Date();
    d.setDate(1);
    d.setMonth(d.getMonth() - i);
    months.push({ key: `${d.getFullYear()}-${d.getMonth()}`, label: d.toLocaleString('en-IN', { month: 'short' }), leads: 0, won: 0 });
  }
  leads.forEach((l) => {
    const c = new Date(l.createdAt);
    const m = months.find((x) => x.key === `${c.getFullYear()}-${c.getMonth()}`);
    if (m) m.leads += 1;
    if (l.status === 'Won') {
      const u = new Date(l.updatedAt);
      const mw = months.find((x) => x.key === `${u.getFullYear()}-${u.getMonth()}`);
      if (mw) mw.won += l.value || 0;
    }
  });

  const stats = {
    total: leads.length,
    open: open.length,
    openValue: open.reduce((a, l) => a + (l.value || 0), 0),
    forecast: Math.round(open.reduce((a, l) => a + (l.value || 0) * ((l.ai?.score || 0) / 100), 0)),
    won: won.length,
    wonValue: won.reduce((a, l) => a + (l.value || 0), 0),
    closed: closed.length,
    winRate: closed.length ? Math.round((won.length / closed.length) * 100) : 0,
    hot: open.filter((l) => l.ai?.label === 'Hot').length,
    overdueTasks: tasks.filter((t) => !t.done && new Date(t.dueDate) < new Date()).length,
    byStatus,
    bySource,
    trend: months.map(({ label, leads: n, won: w }) => ({ month: label, leads: n, won: w })),
  };

  return { leads, tasks, stats };
};
