const mongoose = require('mongoose');

const noteSchema = new mongoose.Schema(
  {
    text: { type: String, required: true },
    sentiment: { type: String, enum: ['positive', 'neutral', 'negative'], default: 'neutral' },
  },
  { timestamps: true }
);

const leadSchema = new mongoose.Schema(
  {
    owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    name: { type: String, required: true, trim: true },
    email: { type: String, trim: true, lowercase: true },
    phone: { type: String, trim: true },
    company: { type: String, trim: true },
    jobTitle: { type: String, trim: true },
    source: {
      type: String,
      enum: ['Website', 'Referral', 'Google Ads', 'Meta Ads', 'LinkedIn', 'Cold Call', 'Event', 'Other'],
      default: 'Website',
    },
    status: {
      type: String,
      enum: ['New', 'Contacted', 'Qualified', 'Proposal', 'Negotiation', 'Won', 'Lost'],
      default: 'New',
    },
    value: { type: Number, default: 0 },
    budget: { type: String, enum: ['Unknown', 'Low', 'Medium', 'High'], default: 'Unknown' },
    tags: [String],
    notes: [noteSchema],
    lastContactedAt: Date,
    ai: {
      score: { type: Number, default: 0 },
      label: { type: String, enum: ['Cold', 'Warm', 'Hot'], default: 'Cold' },
      reasons: [String],
      nextAction: String,
      provider: String,
      scoredAt: Date,
    },
  },
  { timestamps: true }
);

leadSchema.index({ owner: 1, status: 1 });

module.exports = mongoose.model('Lead', leadSchema);
