const mongoose = require('mongoose');

const activitySchema = new mongoose.Schema(
  {
    owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    lead: { type: mongoose.Schema.Types.ObjectId, ref: 'Lead' },
    kind: { type: String, required: true }, // created | status | note | ai | task | email
    message: { type: String, required: true },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Activity', activitySchema);
