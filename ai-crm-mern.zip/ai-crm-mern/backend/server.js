require('dotenv').config();
const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const path = require('path');
const connectDB = require('./config/db');
const protect = require('./middleware/auth');

if (!process.env.JWT_SECRET) {
  console.warn('JWT_SECRET is not set. Using a development default – set it in .env before deploying.');
  process.env.JWT_SECRET = 'dev_secret_change_me';
}

const app = express();
app.use(cors({ origin: process.env.CLIENT_URL || '*' }));
app.use(express.json({ limit: '1mb' }));
app.use(morgan('dev'));

// Wrap async handlers so thrown errors reach the error middleware (Express 4)
const wrap = (router) => {
  router.stack.forEach((layer) => {
    layer.route?.stack.forEach((s) => {
      const fn = s.handle;
      if (fn.constructor.name === 'AsyncFunction') s.handle = (req, res, next) => fn(req, res, next).catch(next);
    });
  });
  return router;
};

app.get('/api/health', (req, res) => res.json({ ok: true }));
app.use('/api/auth', wrap(require('./routes/auth')));
app.use('/api/leads', protect, wrap(require('./routes/leads')));
app.use('/api/tasks', protect, wrap(require('./routes/tasks')));
app.use('/api/dashboard', protect, wrap(require('./routes/dashboard')));
app.use('/api/ai', protect, wrap(require('./routes/ai')));

// Serve the built React app in production (npm run build inside /frontend)
const dist = path.join(__dirname, '..', 'frontend', 'dist');
app.use(express.static(dist));
app.get(/^\/(?!api).*/, (req, res, next) => res.sendFile(path.join(dist, 'index.html'), (err) => err && next()));

app.use((err, req, res, next) => {
  console.error(err);
  if (err.name === 'ValidationError') return res.status(400).json({ message: Object.values(err.errors).map((e) => e.message).join(' ') });
  if (err.name === 'CastError') return res.status(400).json({ message: 'Invalid id.' });
  res.status(500).json({ message: 'Server error. Check the backend console for details.' });
});

const PORT = process.env.PORT || 5000;
connectDB()
  .then(() => app.listen(PORT, () => console.log(`API running on http://localhost:${PORT}`)))
  .catch((e) => {
    console.error('Could not connect to MongoDB. Is it running? ', e.message);
    process.exit(1);
  });
